import "./App.css";
import { useReducer, useRef, useEffect,  createContext } from "react";
import { Routes, Route, BrowserRouter } from "react-router-dom";
import Home from "./pages/Home";
import New from "./pages/New";
import Diary from "./pages/Diary";
import Edit from "./pages/Edit";
//import { type } from "@testing-library/user-event/dist/type";

const mockData = [
  {
    id: "mock1",
    date: new Date().getTime() - 1,
    contents: "mock1",
    emotionId: 1,
  },
  {
    id: "mock2",
    date: new Date().getTime() - 1,
    contents: "mock2",
    emotionId: 2,
  },
  {
    id: "mock3",
    date: new Date().getTime() - 1,
    contents: "mock3",
    emotionId: 3,
  },
];

//컨텍스트 동작 컴포넌트 생성(두개의 컨텍스트 생성)
export const DiaryStateContext = createContext();
export const DiaryDispatchContext = createContext();

function reducer(state, action) {
  switch (action.type) {
    case "INIT": //만들어졌을 때
      return action.data; //데이터 제공
    case "CREATE": //신규 데이터 생성
      return [action.data, ...state]; //기존의 데이터+신규데이터 붙여서 제공
    case "UPDATE": //데이터 업데이트(일부를 꺼내서 수정)
      return state.map(
        (
          it //state의 요소(it)들을 map함수로 하나씩 풀어보기
        ) =>
          String(it.id) === String(action.data.id) ? { ...action.data } : it
      );
    case "DELETE":
      return state.filter(it => String(it.id) !== String(action.targetId));
    //선택받지 못한 애들만 제공(선택된 애들은 삭제)
    default: {
      return state;
    } //switch case에서 항상 마지막 case는 default로(별도의 경우가 아닌 경우)
  }
}

function App() {
  const idRef = useRef(0); //id 0번부터 설정
  const [data, dispatch] = useReducer(reducer, []); //Reducer = useState와 비슷, 세부 case로 나누기 O
  useEffect(
    () => {
      //실행될 콜백
      dispatch({ type: "INIT", data: mockData }); //실행시 목업 데이터 제공하며 init
      //나중에 data:mockData에서 mock이 DB에서 가져오는 것, mysql이랑 연결한 부분으로 고치면 됨.
      //여기서 data에다가 실제 데이터 값을 담아줌.
    },
    [] //취합할 것
  );

  //신규 생성 함수
  const onCreate = (date, contents, emotionId) => {
    //현재 날짜 알려주기 위해 받아옴
    //데이터 CRUD 중 생성을 위한 함수
    dispatch({
      type: "CREATE",
      data: {
        id: idRef.current, //아까 idRef해서 0으로 시작했었음.
        date: new Date(date).getTime(), //지금 날짜 받아오기
        contents, //content = content
        emotionId,
      },
    });
    idRef.current += 1; //다음에 생성될 데이터를 위해 ref값 +1하기
  };
  const onUpdate = (targetId, date, contents, emotionId) => {
    //데이터 CRUD 중 수정을 위한 함수
    dispatch({
      type: "UPDATE",
      data: {
        id: idRef.targetId, //이벤트가 발생한 항목을 가져와아햐니 targetId
        date: new Date(date).getTime(), //지금 날짜 받아오기
        contents, //content = content
        emotionId,
      },
    });
  };
  const onDelete = targetId => {
    //데이터 CRUD 중 삭제를 위한 함수
    dispatch({
      type: "DELETE",
      targetId,
    });
  };

  return (
    //리턴할 컨텐츠 표현
    //react context를 통해 2개의 provider을 구성.
    //value를 통해 provider가 제공하는 것들을 설명.
    //첫번째 provider는 data와같은 정보만 넘겨줌. data는 reducer로 생성,관리.
    //두번째 provider는 onCreate,onUpdate, onDelete등의 함수들을 전달해줌.
    //----
    //이후 라우팅을 위해 BrowerRouter->Routes->Route를 통해 컴포넌트들을 라우팅
    <DiaryStateContext.Provider value={data}>
      <DiaryDispatchContext.Provider value={{ onCreate, onUpdate, onDelete }}>
        <BrowserRouter>
          <div className="App">
            <Routes>
              {" "}
              {/* 라우트 관리 */}
              <Route path="/" element={<Home />} />
              <Route path="/new" element={<New />} />
              <Route path="/diary/:id" element={<Diary />} />
              <Route path="/edit/:id" element={<Edit />} />
            </Routes>
          </div>
        </BrowserRouter>
      </DiaryDispatchContext.Provider>
    </DiaryStateContext.Provider>
  );
}

export default App;
