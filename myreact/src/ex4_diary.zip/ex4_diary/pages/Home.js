import "../style/Home.css";
import Header from "../component/Header";
import DiaryList from "../component/DiaryList";
import Button from "../component/Button";
import { useContext, useEffect, useState } from "react";
import { DiaryStateContext } from "../App";

function Home() {
  const [pivotDate, setPivotDate] = useState(new Date());
  const data = useContext(DiaryStateContext);
  const [filteredData, setFilteredData] = useState([]);
  useEffect(
    () => {}, //12일 진도
    [data, pivotDate]
  );
  const headerTitle = `${pivotDate.getFullYear()}년 ${
    pivotDate.getMonth() + 1
  }월`;

  const onDecreaseMonth = () => {
    setPivotDate(new Date(pivotDate.getFullYear(), pivotDate.getMonth() - 1));
  };
  const onIncreaseMonth = () => {
    setPivotDate(new Date(pivotDate.getFullYear(), pivotDate.getMonth() + 1));
  };

  return (
    <>
      <Header
        title={headerTitle}
        leftChild={<Button text={"<"} onClick={onDecreaseMonth} />}
        rightChild={<Button text={">"} onClick={onIncreaseMonth} />}
      />
      <DiaryList data={filteredData} />
    </>
  );
}

export default Home;
