import "../style/New.css";
import { useContext } from "react";
import { useNavigate } from "react-router-dom";
import Header from "../component/Header";
import Editor from "../component/Editor";
import Button from "../component/Button";
import { DiaryDispatchContext } from "../App";

export default function New() {
  const { onCreate } = useContext(DiaryDispatchContext);
  const navigate = useNavigate();
  const goBack = () => {
    navigate(-1);
  };
  //useNavigate는 이런식으로 -1을 넣어주면 알아서 뒤로 가기 해줌
  const onSubmit = data => {
    //const { date, content, emotionId } = data; //data로부터 date.content.emotionId등의 정보를 받아옴
    onCreate(); //받아온 것들을 토대로 onCreate에 넣기
    navigate("/", { replace: true });
  };

  return (
    <div>
      <Header
        title={"새 일기 작성하기"}
        leftChild={<Button text={"< 뒤로가기"} onClick={goBack} />}
      ></Header>
      <Editor onSubmit={onSubmit} />
    </div>
  );
}
