import "../style/DiaryList.css";
import Button from "./Button";
import DiaryItem from "./DiaryItem";

const sortOptionList = [
  //나중 정렬 방식 선택을 위해 미리 배열에 값 담아두기
  { value: "latest", name: "최신순" },
  { value: "oldest", name: "오래된 순" },
];

//map을 잘 써야하는구나!

export default function DiaryList() {
  return (
    <div className="diarylist">
      <div className="menu-wrapper">
        <div className="sort-col">
          <select value={sortType} onChange={onChangeSortType}>
            {sortOptionList.map((it, index) => (
              <option key={index} value={it.value}>
                {it.name}
              </option>
            ))}
          </select>
        </div>
        <div className="create-col">
          <Button text={"새 일기 쓰기"} onClick={onClickNew} />
        </div>
      </div>
      <div className="list-wrapper">
        {sortedData.map(it => (
          <DiaryItem key={it.id} {...it} />
        ))}
      </div>
    </div>
  );
}
