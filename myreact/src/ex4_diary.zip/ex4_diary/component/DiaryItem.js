import "../style/DiaryItem.css";
import React from "react";
import { useNavigate } from "react-router-dom"; //임포트 해와야함
import Button from "./Button";
import { getEmotionImgById } from "../util";

export default function DiaryItem({ id, emotionId, content, date }) {
  const navigate = useNavigate(); //a태그 같은 역할
  const goDetail = () => {
    //실행 시 navigate함수를 통해 해당 경로로 이동
    navigate(`/diary/${id}`);
  };
  const goEdit = () => {
    navigate(`/edit/${id}`);
  };

  return (
    <div className="diary-item">
      <div
        onClick={goDetail}
        className={["img-section", `img-section-${emotionId}`].join(" ")}
      >
        <img src={getEmotionImgById(emotionId)} alt="" />
      </div>
      <div className="info-section" onClick={goDetail}>
        <div className="date-wrapper">
          {new Date(parseInt(date)).toLocaleDateString()}
        </div>
        <div className="content-wrapper">{content.slice(0, 25)}</div>
      </div>
      <div className="btn-section">
        <Button text={"수정하기"} onClick={goEdit} />
      </div>
    </div>
  );
}
